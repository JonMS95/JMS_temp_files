/*
    What's a database?
    A database is a structured collection of data organized into tables.
    Tables consist of rows (records) and columns (fields).
    SQL databases are relational, so they can link data across different tables via keys.

    Is a database like a matrix?
    Superficially, yes. An SQL table is a 2D structure with rows and columns. However, there are
    subtle differences with an actual matrix: a database has different data types per column, unique
    identifiers for each row and schemas to define their structure, whereas all of the just mentioned
    do not exist in common matrices.
*/

-- Example: create a sample table.

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,   -- PRIMARY KEY: creates a unique row ID. AUTOINCREMENT: ensures it increments by itself without explicitly telling each time.
    name TEXT NOT NULL,			            -- NOT NULL: ensures that target column must have a value.
    email TEXT UNIQUE NOT NULL,		        -- UNIQUE: prevents duplicates in a column.
    age INTEGER DEFAULT 0		            -- DEFAULT: sets a value if none is provided.
);

/*
    What data types exist in SQL?
    They can be split into several categories
        ·Numeric: INT, SMALLINT, BIGINT, DECIMAL(p,s),NUMERIC, FLOAT, REAL, DOUBLE.
        ·Text:  CHAR(n), VARCHAR(n), TEXT.
        ·Date/Time: DATE, TIME, TIMESTAMP, DATETIME, INTERVAL.
        ·Boolean: BOOLEAN.
        ·Binary: BLOB, BYTEA.
        ·Other: ENUM, UUID, JSON, XML
    It can be said that arguably, INTEGER, TEXT, REAL, NUMERIC are TEXT the most common ones among
    the ones stated above.

    What's a primary key?
    A database must include a primary key. Such primary key is a constraint that uniquely identifies
    each row in a table so as to query them afterwards (if two rows had equal primary keys, it would
    be simply impossible to refer only to one of them).
    Primary key should be unique per table, and it can be a single column (typical) ir be a composite
    key, formed across multiple columns (for instance, user_id and order_id).
    A PRIMARY KEY is NOT NULL and UNIQUE by default, so there's no need to explicitly mark them as
    UNIQUE NOT NULL (it's not recommended indeed).
    Primary keys are commonly placed in the first column of a table, but this is not an actual
    requirement, but a commonly followed convention instead.

    Does AUTOINCREMENT automatically increment each new record's primary key?
    Yes, but there's a nuance to grasp. If you declare the primary key in question as
    INTEGER PRIMARY KEY, it will be auto-incremented by finding the current largest existing value
    and incrementing it (usually +1).
    On the other hand, AUTOINCREMENT is a bit more strict, since ID's are never reused even if rows
    are deleted. It's a bit slower than plain INTEGER PRIMARY KEY behaviour, but it applies the
    previously explained "never-reuse-ID" policy.

    What if a non-NULL column is inserted if explicitly specified to be not NULL?
    NOT NULL is a column constraint that ensures that a column cannot contain NULL values. In SQL,
    NULL represents a missing or unknown value (so it's not the same as zero or an empty string,
    but the absence of any value instead).
    Therefore, if no value is inserted at all, the database will simply reject the insertion an
    error.

    What if two different records have the same value in a given column?
    UNIQUE constraint ensures that no two rows in a table can have the same value in that column
    (or group of columns if the constraint is composite).
    Same as with NOT NULL, trying to insert a repeated value leads to an error.
*/

-- Example: insert data into the previously created table.

INSERT INTO users (name, email, age) VALUES ('Alice', 'alice@example.com', 30);

INSERT INTO users (age, name, email) VALUES (35, 'Bob', 'spongebob@squarepants.com'), (30, 'Jon', 'jon@swe.com');

/*
    As seen in the example above, new records can be inserted into a table. They can be inserted one
    by one or many at once. The order in which the columns for a given record are specified does
    as long as it's coherent with the expected data type.
    
*/
